import json
import sys, os
import pandas as pd
from collections import Counter

topic_set = {'1': 'Ordinary_Life', '2': 'School_Life', '3': 'Culture&Education',
             '4': 'Attitude&Emotion', '5': 'Relationship', '6': 'Tourism',
             '7': 'Health', '8': 'Work', '9': 'Politics', '10': 'Finance'}

def read_json(filename):
    with open(filename, 'r') as f:
        data = json.load(f)
    return data

def write_json(filename, d):
    with open(filename, 'w') as f:
        json.dump(d, f, indent=4)
    return filename

def read_dailydialog(base_dir):
    # Open files
    in_dial = open(os.path.join(base_dir, 'dialogues_text.txt'), 'r')
    in_topic = open(os.path.join(base_dir, 'dialogues_topic.txt'), 'r')

    data = {'text': [], 'topic': []}
    for line_count, (line_dial, line_topic) in enumerate(zip(in_dial, in_topic)):
        topic = line_topic.strip()
        
        seqs = line_dial.split('__eou__')
        seqs = seqs[:-1]
        for i in range(len(seqs)):
            seqs[i] = seqs[i].strip()
        
        data['text'].append(seqs)
        data['topic'].append(topic_set[topic])

    return data['text']

if __name__ == '__main__':
    base_dir = sys.argv[1]
    text = read_dailydialog(base_dir)
    data = read_json('DiaLog.json')
    speaker = ['S1 : ', 'S2 : ']
    
    train, test = [], []
    for i, d in enumerate(data):
        idx = d['dialog_id']
        for k in range(1, len(d['events'])+1):
            for j in range(1, 3):
                content = ''
                for tid, t in enumerate(text[idx][:k]):
                    content += (speaker[tid % 2]+t+'\n')
                id = '{}-{}-{}'.format(idx, j, k)
                label = ','.join(d['events'][k-1]['S'+str(j)]) if len(d['events'][k-1]['S'+str(j)]) else 'NoEvent'
                temp = [id, 'S'+str(j), content, label]
                if i < 500: train.append(temp)
                else: test.append(temp)
    
    col = ['id', 'person', 'dialog', 'label']
    
    df_train = pd.DataFrame(train, columns=col)
    df_test = pd.DataFrame(test, columns=col)
    df_train.to_csv('train.csv', sep='\t', index=False)
    df_test.to_csv('test.csv', sep='\t', index=False)